#!/bin/sh

clear

if
   g++ main.cpp
then
   ./a.out
fi
