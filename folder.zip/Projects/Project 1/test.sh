#!/bin/sh

clear

if
   make
then
   ./a.out
   
   make clean
fi
