#!/bin/sh

clear

rm a.out

if
   g++ main.cpp
   then
      ./a.out
fi
